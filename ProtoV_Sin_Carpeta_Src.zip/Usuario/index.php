<?php
    session_start();
    //Hacemos comprobacion de que esta autenticado porque de aqui se vana desplegar las demas cosas,
    //En cada php que sea de User y se muestre se debe hacer la comprobacion
    require '../includes/funciones.php';
    require '../includes/config/database.php';
    //Se hace desde el index que es el que desplegara toda la informacion del usuario
    if(estaAutenticado());
    
    $db = conectarDB(); // Conexión a la base de datos
    incluirTemplate('header');    

    include 'Visualizardatos/Datosprincipales.php';
        
    

    ?>



<?php 
    
    incluirTemplate('footer');
    $db->close();
?>