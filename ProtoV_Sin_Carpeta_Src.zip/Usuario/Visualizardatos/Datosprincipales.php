<?php

$Id_user = $_SESSION['usuario'];


// Preparamos la consulta SQL para evitar inyección SQL
$query = "SELECT * FROM usuarios WHERE Id = ?";
$stmt = mysqli_prepare($db, $query);

if ($stmt) {
    // Vinculamos el parámetro (i para indicar que es un entero)
    mysqli_stmt_bind_param($stmt, 'i', $Id_user);

    // Ejecutamos la consulta
    mysqli_stmt_execute($stmt);

    // Obtenemos los resultados
    $resultado = mysqli_stmt_get_result($stmt);

    // Verificamos si encontramos al usuario
    if ($fila = mysqli_fetch_assoc($resultado)) {
        // Accedemos a la tabla usuarios
        $NombreUser = $fila['Nombre'];
        $ApPat = $fila['ApPat'];
        $ApMat = $fila['ApMat'];
        $CubTot = $fila['CubetasTot'];
        $FechaNac = $fila['FNacimiento'];
        $FRegistro = $fila['FRegistro'];

        // Cálculo de la edad
        date_default_timezone_set('America/Mexico_City'); // Configura la zona horaria a México
        $fecha_actual = new DateTime(); // Fecha actual
        $fecha_nacimiento = new DateTime($FechaNac); // Fecha de nacimiento como objeto DateTime
        $edad = $fecha_actual->diff($fecha_nacimiento)->y; // Calcula la diferencia en años (edad)

        // Ahora calcular en días el tiempo desde la fecha de registro
        $fecha_registro = new DateTime($FRegistro);

        // Calculamos la diferencia en días
        $diferencia_dias = $fecha_actual->diff($fecha_registro)->days; // Diferencia en días
    } else {
        // Usuario no encontrado
        header('Location: ../../index.php');
        exit;
    }
    // Cerramos la declaración
    mysqli_stmt_close($stmt);
}

// Calculamos las cubetas restantes
$CubetasRes = $CubTot % 4;
$CubetasRes = 4 - $CubetasRes;
if ($edad > 120)
    $edad = 'Fecha mal proporcionada';

// Mostramos el perfil
echo '
<section class="perfil">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"
        stroke-linecap="round" stroke-linejoin="round" width="24" height="24" stroke-width="2">
        <path d="M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0"></path>
        <path d="M6 21v-2a4 4 0 0 1 4 -4h4"></path>
        <path d="M15 19l2 2l4 -4"></path>
    </svg>
    <p class="nombre">Nombre : '.$NombreUser.' </p>
    <p class="dato">Edad : '.$edad.'</p>
    <p class="dato">Cubetas Totales : '.$CubTot.'</p>
    <p class="dato">ID : '.$Id_user.' </p>
    <p class="dato">Apellido Paterno : '.$ApPat.' </p>
    <p class="dato">Apellido Materno : '.$ApMat.' </p>
    <p class="dato">Tiempo en vive composta : '.$diferencia_dias.' días</p>
    <p class="dato">Cubetas Restantes para la siguiente meta : '.$CubetasRes.'</p>
</section>

<a href="../cerrarSesion.php" class="BotonCerrarSesion">Cerrar sesion</a>
';

?>
