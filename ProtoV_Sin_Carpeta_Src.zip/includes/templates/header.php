<?php
    
    $BusquedaUser = '';
// Comprobar si el formulario fue enviado y el parámetro está definido
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['BuscarPorID']) && $_GET['BuscarPorID'] !== '') {
    
    $db = conectarDB();
    // Obtener el valor del parámetro
    $BusquedaUser = intval($_GET['BuscarPorID']); // Convertir a entero
    //sanitizamos la entrada
    $BusquedaUser = filter_var($BusquedaUser, FILTER_SANITIZE_NUMBER_INT);
        //codigo para busqueda por id en la pagina principal header en desktop

        // Variables para la consulta
        $Nombre = '';
        $CubetasRestantes = 0;
        $CubetasTotales = 0;
        $ArregloIDs = [];

        // Crear la consulta para obtener todos los IDs
        $ConsultaPorID = 'SELECT ID FROM usuarios;';
        $resultado = mysqli_query($db, $ConsultaPorID);

        if ($resultado) {
            while ($fila = mysqli_fetch_assoc($resultado)) {
                $ArregloIDs[] = intval($fila['ID']); // Guardar los IDs como enteros
            }
        }
        // Verificar si se proporcionó un ID válido
        if ($BusquedaUser !== '' && in_array($BusquedaUser, $ArregloIDs)) {
            // Consulta para obtener los datos del usuario
            $stmt = $db->prepare("SELECT Nombre, CubetasTot FROM usuarios WHERE ID = ?");
            $stmt->bind_param("i", $BusquedaUser);
            $stmt->execute();
            $resultadoDatos = $stmt->get_result();

            if ($resultadoDatos && $datos = $resultadoDatos->fetch_assoc()) {
                $Nombre = $datos['Nombre'];
                $CubetasTotales = $datos['CubetasTot'];
                $CubetasRestantes = $CubetasTotales % 4;

                // Calcular cuántas cubetas faltan para completar el múltiplo de 4
                $CubetasFaltantes = 4 - $CubetasRestantes;

                if ($CubetasTotales == 0) {
                    $mensaje = "<p class='centrado felicitacion'>Bienvenid@ a ViveComposta!!</p>
                                <p class='justificado'>Junta 4 cubetas para recibir una recompensa</p>";
                } else {
                    // Construir el mensaje dinámico
                    $mensaje = $CubetasRestantes === 0 
                        ? "<p class='centrado felicitacion'>Felicidades!!</p> <p class='justificado'>Puedes pasar por tu composta si aún no lo has hecho.</p>"
                        : "<p class='justificado'>Te faltan $CubetasFaltantes cubetas, ¡sigue así!</p>";
                }
                echo "
                    <div class='Oscurecer' id='MiniRecuadro'>
                        <svg class='iconocierreBusqueda' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-linecap='round' stroke-linejoin='round' stroke-width='3'> 
                            <path d='M18 6l-12 12'></path> 
                            <path d='M6 6l12 12'></path> 
                        </svg>
                    </div>
                    
                    <div class='datosGeneralesUser' id='MiniRecuadro2'>
                        <h3>Hola $Nombre</h3>
                        $mensaje
                    </div>
                ";
            }
        }
    mysqli_close($db);
}

// Borra todas las variables de la sesión
/*
session_unset();  // Elimina todas las variables de sesión

// Destruye la sesión (esto borra los datos de la sesión en el servidor)
session_destroy();

//borra las cookies para poder iniciar sesion de nuevo
setcookie(session_name(), "", time() - 3600, "/");
*/


?>


<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Pagina Web de empresa ViveComposta, dedicada a la transformacion de residuos organicos">
    <meta name="keywords" content="residuos orgánicos, composta, ViveComposta, Empresa de reciclaje, clientes, comunidad">
    <meta name="author" content="<?php echo $inicio ? "Equipo GreenSW" : "David Zaragoza, Diego Fuentes, Aletia Villasis, Alejandro Medina";?>">
    <title>Vive Composta</title>

    <link rel="stylesheet" href="/ProtoV/build/css/app.css">
    <link rel="shortcut icon" href="/ProtoV/build/img/logos/3vc_isotipo.webp" type="image/x-icon">

</head>

<body>
    <header class="NavegacionDesktop">
        <?php echo $inicio ? '
        <div class="Redes_princ">
            <li class="Redes">
                <a href="https://www.instagram.com/vive_composta/?hl=es-la" target="_blank">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                        stroke-linecap="round" stroke-linejoin="round" stroke-width="2">
                        <path d="M4 4m0 4a4 4 0 0 1 4 -4h8a4 4 0 0 1 4 4v8a4 4 0 0 1 -4 4h-8a4 4 0 0 1 -4 -4z"></path>
                        <path d="M12 12m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0"></path>
                        <path d="M16.5 7.5l0 .01"></path>
                    </svg>
                </a>
                <a href="https://www.facebook.com/Vivecomposta" target="_blank">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path
                            d="M18 2a1 1 0 0 1 .993 .883l.007 .117v4a1 1 0 0 1 -.883 .993l-.117 .007h-3v1h3a1 1 0 0 1 .991 1.131l-.02 .112l-1 4a1 1 0 0 1 -.858 .75l-.113 .007h-2v6a1 1 0 0 1 -.883 .993l-.117 .007h-4a1 1 0 0 1 -.993 -.883l-.007 -.117v-6h-2a1 1 0 0 1 -.993 -.883l-.007 -.117v-4a1 1 0 0 1 .883 -.993l.117 -.007h2v-1a6 6 0 0 1 5.775 -5.996l.225 -.004h3z">
                        </path>
                    </svg>
                </a>
                <a href="https://www.tiktok.com/@vive_composta" target="_blank">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path
                            d="M16.083 2h-4.083a1 1 0 0 0 -1 1v11.5a1.5 1.5 0 1 1 -2.519 -1.1l.12 -.1a1 1 0 0 0 .399 -.8v-4.326a1 1 0 0 0 -1.23 -.974a7.5 7.5 0 0 0 1.73 14.8l.243 -.005a7.5 7.5 0 0 0 7.257 -7.495v-2.7l.311 .153c1.122 .53 2.333 .868 3.59 .993a1 1 0 0 0 1.099 -.996v-4.033a1 1 0 0 0 -.834 -.986a5.005 5.005 0 0 1 -4.097 -4.096a1 1 0 0 0 -.986 -.835z">
                        </path>
                    </svg>
                </a>
            </li>
            <h1>Generando gramos de vida</h1>
            <div class="InicioS">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                    stroke-linecap="round" stroke-linejoin="round" stroke-width="2">
                    <path d="M10 10m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0"></path>
                    <path d="M21 21l-6 -6"></path>
                    
                </svg>
                <form class="BusquedaInS" action="" method="GET">
                    <input type="number" class="AreaBuscar" id="BuscarCuebetas" name="BuscarPorID" placeholder="ID :" autocomplete="off" value="'.$BusquedaUser.'">
                </form>

                <a href="/ProtoV/login.php">
                    <h1 class="TextoIniciar"> Iniciar sesión</h1>
                </a>
            </div>
        </div>' : '';  ?>

        <nav class="NavPrincipal">
            <a class="Logo" href="/ProtoV/index.php">
                <img src="/ProtoV/build/img/Logos/1vc_logo_horiz.webp" alt="Logo ViveC">
            </a>
            <ul class="Menu">
                <a href="#">NOSOTROS</a>
                <a href="#Ubic">UBICACIONES</a>
                <a href="#">COMPOSTA</a>
                <a href="#">PREGUNTAS</a>
                <a href="#fot">CONTACTO</a>
            </ul>

            
        </nav>
    </header>


        