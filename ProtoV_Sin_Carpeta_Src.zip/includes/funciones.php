<?php

require 'app.php';

function incluirTemplate( string  $nombre, bool $inicio = false ) {
    include TEMPLATES_URL."/{$nombre}.php"; 
}

function estaAutenticado() : bool {

    $auth = $_SESSION['login'] ?? NULL;

    if (!$auth) {
        return false;
    }
    return true; // Retornar true si el usuario está autenticado
}

function QueRolTiene() : int {
    //para hacer la conexion y verificar el rol del usuario
    //primero hacemos conexion
    $db = conectarDB();
    //hacemos consulta por preparadas
    $query = "SELECT * FROM usuarios WHERE Id = ?";
    $stmt = $db->prepare($query);
    if($stmt){
        $stmt->bind_param('i', $_SESSION['usuario']);
        $stmt->execute();
        $resultado = $stmt->get_result();
        //si se encontro el usuario
        if ($resultado && $resultado->num_rows){
            //obtenemos la unica tupla por su Id unico
            $usuario = $resultado->fetch_assoc();
            //hacemos operacion ternaria
            return $usuario['Rol'] == "User" ? 1 : 0;
            //1 para usuario normal 0 para administrador
        }//Si no se encontro en caso de que los datos hayan sido modificados
        else{
            unset($_SESSION['usuario']);
            header ('Location: /');
            exit;
        }
    }
    $db->close();
}