<?php
    require './includes/config/database.php';
    require 'includes/funciones.php';
    
    incluirTemplate('header',true);

?>

        <main class="cont_principal">
            <div class="Flayer">
                <picture>
                    <img class="DesktopFlayer" src="/ProtoV/build/img/Portadas_Estaticas/Layer_Desktop.webp" alt="">
                    <img class="MobileFlayer" src="/ProtoV/build/img/Portadas_Estaticas/Layer_Mobile.webp" alt="">
                </picture>
            </div>

            <section class="proceso">
                <div class="UnirseProc">
                    <h3>¿Cómo es el proceso para unirme?</h3>
                    <p>Estás a una cubeta amarilla de devolverle vida a la tierra</p>

                    <a href="#" >¡Cuéntame más!</a>
                </div>
                <div class="imagen">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                        stroke-linecap="round" stroke-linejoin="round" width="24" height="24" stroke-width="2">
                        <path d="M12 17l-2 2l2 2"></path>
                        <path d="M10 19h9a2 2 0 0 0 1.75 -2.75l-.55 -1"></path>
                        <path d="M8.536 11l-.732 -2.732l-2.732 .732"></path>
                        <path d="M7.804 8.268l-4.5 7.794a2 2 0 0 0 1.506 2.89l1.141 .024"></path>
                        <path d="M15.464 11l2.732 .732l.732 -2.732"></path>
                        <path d="M18.196 11.732l-4.5 -7.794a2 2 0 0 0 -3.256 -.14l-.591 .976"></path>
                    </svg>
                </div>
            </section>
            
            <section class="Ubicaciones" id="Ubic">
                <h3>Ubicaciones Centros de Acopio</h3>
                <div class="gridPc">
                    <article class="MasEspacio elemento_anim"><a href="#">
                        <svg xmlns="http://www.w3.org/2000/svg" class="ImagenUb" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" width="36" height="36" stroke-width="2">
                            <path d="M3 21h18"></path>
                            <path d="M19 21v-4"></path>
                            <path d="M19 17a2 2 0 0 0 2 -2v-2a2 2 0 1 0 -4 0v2a2 2 0 0 0 2 2z"></path>
                            <path d="M14 21v-14a3 3 0 0 0 -3 -3h-4a3 3 0 0 0 -3 3v14"></path>
                            <path d="M9 17v4"></path>
                            <path d="M8 13h2"></path>
                            <path d="M8 9h2"></path>
                        </svg>
                            <h4>1. Satélite, Zona Azul</h4>
                        </a></article>
                    <article class="elemento_anim"><a href="#">
                        <svg xmlns="http://www.w3.org/2000/svg" class="ImagenUb" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" width="36" height="36" stroke-width="2">
                                <path d="M3 21h18"></path>
                                <path d="M19 21v-4"></path>
                                <path d="M19 17a2 2 0 0 0 2 -2v-2a2 2 0 1 0 -4 0v2a2 2 0 0 0 2 2z"></path>
                                <path d="M14 21v-14a3 3 0 0 0 -3 -3h-4a3 3 0 0 0 -3 3v14"></path>
                                <path d="M9 17v4"></path>
                                <path d="M8 13h2"></path>
                                <path d="M8 9h2"></path>
                            </svg>
                            <h4>2. La florida</h4>
                        </a></article>
                    <article class="elemento_anim"><a href="#">
                        <svg xmlns="http://www.w3.org/2000/svg" class="ImagenUb" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" width="36" height="36" stroke-width="2">
                                <path d="M3 21h18"></path>
                                <path d="M19 21v-4"></path>
                                <path d="M19 17a2 2 0 0 0 2 -2v-2a2 2 0 1 0 -4 0v2a2 2 0 0 0 2 2z"></path>
                                <path d="M14 21v-14a3 3 0 0 0 -3 -3h-4a3 3 0 0 0 -3 3v14"></path>
                                <path d="M9 17v4"></path>
                                <path d="M8 13h2"></path>
                                <path d="M8 9h2"></path>
                            </svg>
                            <h4>3. Chiluca</h4>
                        </a></article>
                    <article class="elemento_anim"><a href="#">
                        <svg xmlns="http://www.w3.org/2000/svg" class="ImagenUb" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" width="36" height="36" stroke-width="2">
                                <path d="M3 21h18"></path>
                                <path d="M19 21v-4"></path>
                                <path d="M19 17a2 2 0 0 0 2 -2v-2a2 2 0 1 0 -4 0v2a2 2 0 0 0 2 2z"></path>
                                <path d="M14 21v-14a3 3 0 0 0 -3 -3h-4a3 3 0 0 0 -3 3v14"></path>
                                <path d="M9 17v4"></path>
                                <path d="M8 13h2"></path>
                                <path d="M8 9h2"></path>
                            </svg>
                            <h4>4. Condado de Sayavedra</h4>
                        </a></article>
                    <article class="elemento_anim"><a href="#">
                        <svg xmlns="http://www.w3.org/2000/svg" class="ImagenUb" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" width="36" height="36" stroke-width="2">
                                <path d="M3 21h18"></path>
                                <path d="M19 21v-4"></path>
                                <path d="M19 17a2 2 0 0 0 2 -2v-2a2 2 0 1 0 -4 0v2a2 2 0 0 0 2 2z"></path>
                                <path d="M14 21v-14a3 3 0 0 0 -3 -3h-4a3 3 0 0 0 -3 3v14"></path>
                                <path d="M9 17v4"></path>
                                <path d="M8 13h2"></path>
                                <path d="M8 9h2"></path>
                            </svg>
                            <h4>5. Paseo de Echegaray</h4>
                        </a></article>
                    <article class="elemento_anim"><a href="#">
                        <svg xmlns="http://www.w3.org/2000/svg" class="ImagenUb" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" width="36" height="36" stroke-width="2">
                                <path d="M3 21h18"></path>
                                <path d="M19 21v-4"></path>
                                <path d="M19 17a2 2 0 0 0 2 -2v-2a2 2 0 1 0 -4 0v2a2 2 0 0 0 2 2z"></path>
                                <path d="M14 21v-14a3 3 0 0 0 -3 -3h-4a3 3 0 0 0 -3 3v14"></path>
                                <path d="M9 17v4"></path>
                                <path d="M8 13h2"></path>
                                <path d="M8 9h2"></path>
                            </svg>
                            <h4>6. Satélite, Centro cívico</h4>
                        </a></article>
                </div>
            </section>

            <section class="seguimiento">
                <h3>¡Síguenos en nuestras redes sociales!</h3>
                <p>Forma parte de la mejor comunidad y enterate de más.</p>
                <div class="items">
                    <a href="https://www.instagram.com/vive_composta/?hl=es-la" target="_blank">
                        <div class="item">    
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-linecap="round" stroke-linejoin="round" stroke-width="2">
                                <path d="M4 4m0 4a4 4 0 0 1 4 -4h8a4 4 0 0 1 4 4v8a4 4 0 0 1 -4 4h-8a4 4 0 0 1 -4 -4z"></path>
                                <path d="M12 12m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0"></path>
                                <path d="M16.5 7.5l0 .01"></path>
                            </svg>    
                        </div>
                    </a>
                    <a href="https://www.facebook.com/Vivecomposta" target="_blank">
                    <div class="item">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path
                                d="M18 2a1 1 0 0 1 .993 .883l.007 .117v4a1 1 0 0 1 -.883 .993l-.117 .007h-3v1h3a1 1 0 0 1 .991 1.131l-.02 .112l-1 4a1 1 0 0 1 -.858 .75l-.113 .007h-2v6a1 1 0 0 1 -.883 .993l-.117 .007h-4a1 1 0 0 1 -.993 -.883l-.007 -.117v-6h-2a1 1 0 0 1 -.993 -.883l-.007 -.117v-4a1 1 0 0 1 .883 -.993l.117 -.007h2v-1a6 6 0 0 1 5.775 -5.996l.225 -.004h3z">
                            </path>
                        </svg>
                    </div>
                    </a>
                    <a href="https://www.tiktok.com/@vive_composta" target="_blank">
                    <div class="item">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path
                                d="M16.083 2h-4.083a1 1 0 0 0 -1 1v11.5a1.5 1.5 0 1 1 -2.519 -1.1l.12 -.1a1 1 0 0 0 .399 -.8v-4.326a1 1 0 0 0 -1.23 -.974a7.5 7.5 0 0 0 1.73 14.8l.243 -.005a7.5 7.5 0 0 0 7.257 -7.495v-2.7l.311 .153c1.122 .53 2.333 .868 3.59 .993a1 1 0 0 0 1.099 -.996v-4.033a1 1 0 0 0 -.834 -.986a5.005 5.005 0 0 1 -4.097 -4.096a1 1 0 0 0 -.986 -.835z">
                            </path>
                        </svg>
                    </div>
                    </a>
                </div>

            </section>
            <div class="RecuadroChat" id="ChatContent">
                <button class="BotonCerraChatBot" id="CerrarChat"><h3>X</h3></button>
                <h3>¿Necesitas ayuda?</h3>
                <p>Estamos aquí para ayudarte en lo que necesites</p>
                <a href="#">¡Chatea con nosotros!</a>
            </div>
            <div class="chat" id="ChatBoton">
                <svg class="IconoChat" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 64 64">
                    <path d="M 14.638672 10 C 10.984316 10 8 12.984316 8 16.638672 L 8 39.361328 C 8 42.754988 10.6076 45.464176 13.900391 45.849609 C 13.419983 49.110528 12.162225 52.443244 9.4648438 54.15625 A 1.0001 1.0001 0 0 0 10 56 C 16.782051 56 20.708117 53.012513 22.732422 49.638672 C 24.756727 46.264831 25 42.611111 25 41 A 1.0001 1.0001 0 1 0 23 41 C 23 42.388889 22.743273 45.735169 21.017578 48.611328 C 19.602705 50.96945 17.17226 53.000442 12.955078 53.685547 C 14.956143 51.246785 15.864155 48.011929 16.138672 45.076172 A 1.0001 1.0001 0 0 0 15.111328 43.984375 L 14.634766 44 C 12.062984 43.997861 10 41.934811 10 39.361328 L 10 16.638672 C 10 14.065027 12.065027 12 14.638672 12 L 49.361328 12 C 51.934973 12 54 14.065027 54 16.638672 L 54 39.361328 C 54 41.934973 51.934973 44 49.361328 44 L 28 44 A 1.0001 1.0001 0 1 0 28 46 L 49.361328 46 C 53.015684 46 56 43.015684 56 39.361328 L 56 16.638672 C 56 12.984316 53.015684 10 49.361328 10 L 14.638672 10 z"></path>
                </svg>
            </div>
        </main>

    <script src="./build/js/app.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Función para que el Nav nos siga
            navDesktop();
            //Funcion para desplegar el chat
            DesplegarChat();
        });
    </script>
    <script src="./build/js/modernizr.js"></script>
</body>

    <?php
        incluirTemplate('footer');