<?php
include 'includes/funciones.php';
require 'includes/config/database.php';

// Iniciar sesión
session_start();

if(estaAutenticado()){
    $Rol = QueRolTiene();
    $Rol === 1 ? header('Location: /ProtoV/Usuario/index.php') : header('Location: /ProtoV/Admin/index.php');
    exit;
}

// Incluir el encabezado
incluirTemplate('header');

$DatoIngresadoUsuario='';
//Recuadro cuando alguien se registra
// Verificamos si el nombre está en la sesión
if (isset($_SESSION['nombre'])) {
    $nombre = $_SESSION['nombre'];
    recibir_nombre($nombre);
    unset($_SESSION['nombre']); // Eliminamos el nombre de la sesión después de usarlo
}

// Array para almacenar errores
$errores = [];
$auth = false;


// Procesar el formulario cuando se envía
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Conexión a la base de datos
    $db = conectarDB();

    if (!$db) {
        die("Error al conectar a la base de datos.");
    }

    // Obtener y sanitizar datos del formulario
    $email_or_phone = trim($_POST['email_or_phone'] ?? '');
    $password = $_POST['password'] ?? '';

    $errores = [];

    if (empty($errores)) {
        // Consultar si el usuario existe
        $query = "SELECT * FROM usuarios WHERE Correo = ? OR Telefono = ?";
        $stmt = $db->prepare($query);

        if ($stmt) {
            $stmt->bind_param('ss', $email_or_phone, $email_or_phone);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado && $resultado->num_rows) {
                // El usuario existe, verificar contraseña
                $usuario = $resultado->fetch_assoc();
                if (password_verify($password, $usuario['Contrasena'])) {
                    // Autenticación exitosa, iniciar sesión
                    session_start();
                    $_SESSION['usuario'] = $usuario['Id'];
                    $_SESSION['login'] = true;
                    
                    $usuario['Rol']=='Admin'? header('Location: Admin/index.php') : header('Location: Usuario/index.php');

                    exit;
                } else {
                    $DatoIngresadoUsuario = $email_or_phone;
                    $errores[] = "La contraseña es incorrecta.";
                }
            } else {
                $errores[] = "El usuario no existe.";
            }

            $stmt->close();
        } else {
            $errores[] = "Error en la consulta.";
        }
        $db->close();
    }
}

?>

<section class="log">
    <!-- Mostrar errores -->
    <?php foreach ($errores as $error): ?>
        <div class="alerta error">
            <?php echo "<p class='errorloging'>".$error."</p>"; ?>
        </div>
    <?php endforeach; ?>

    <form class="login-form" method="POST" action="">
        <h2>Iniciar Sesión</h2>
        <div class="datos">
            <div class="form-group">
                <label for="email-or-phone">Correo o Número de Teléfono</label>
                <input 
                    type="text" 
                    id="email-or-phone" 
                    name="email_or_phone" 
                    placeholder="Ingrese su correo o número" 
                    required
                    <?php
                        echo 'value="'.$DatoIngresadoUsuario.'"';
                    ?>
                >
            </div>
            <div class="form-group">
                <label for="password">Contraseña</label>
                <div class="Contenedor_contrasena">
                    <input 
                        type="password" 
                        id="password" 
                        name="password" 
                        placeholder="Ingrese su contraseña" 
                        required  
                    >
                    <button type="button" id="IngresarContraseñaSesion" class="toggle-password">👁️</button>
                </div>
            </div>
            <button type="submit" class="BotonInicioS">Iniciar Sesión</button>
            <div class="create-account">
                <p>¿No tienes una cuenta? <a href="registro.php">Crear Cuenta</a></p>
            </div>
        </div>
    </form>
</section>

<!--Incluimos el script para que lo podamos ejecutar desde esta seccion de login-->
    <script src="./build/js/app.js"></script>
<?php
// Incluir el pie de página
incluirTemplate('footer');

function recibir_nombre($nombre){
    echo "  
        <div class='RegistroExitoso' id='registroExitoso'>
            <h3>Registro exitoso.</h3> 
            <p>Bienvenid@ a ViveComposta ".$nombre."</p>
        </div>
    ";

    echo "
    <script>
        setTimeout(function(){
            document.getElementById('registroExitoso').style.display = 'none';
        }, 10000);  //10000 ms = 10 segundos
    </script>
    ";
}
?>
