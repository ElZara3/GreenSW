<?php

function ImprimirUser($NombreUser, $edad, $CubTot, $IDConsultada, $ApPat, $ApMat, $diferencia_dias, $CubetasRes, $Rol) {
    echo '
    <section class="perfil">
        <p class="nombre">Nombre : ' . $NombreUser . '</p>
        <p class="dato">Edad : ' . $edad . '</p>
        <p class="dato">Cubetas Totales : ' . $CubTot . '</p>
        <p class="dato">ID : ' . $IDConsultada . '</p>
        <p class="dato">Apellido Paterno : ' . $ApPat . '</p>
        <p class="dato">Apellido Materno : ' . $ApMat . '</p>
        <p class="dato">Tiempo en vive composta : ' . $diferencia_dias . ' días</p>
        <p class="dato">Cubetas Restantes para la siguiente meta : ' . $CubetasRes . '</p>
        <p class="dato">Rol de Usuario : ' . strtoupper($Rol) . '</p>
    </section>
    ';
}

// Inicializamos las variables de mensajes
$mensaje = '';
$mensajeCubetas = '';

// Procesamiento del formulario para cambiar rol
if (isset($_POST['cambiarRol'])) {
    $idUsuario = (int) filter_var($_POST['idUsuario'], FILTER_SANITIZE_NUMBER_INT);
    $nuevoRol = htmlspecialchars(trim($_POST['nuevoRol']), ENT_QUOTES, 'UTF-8');
    if ($nuevoRol === 'Admin' || $nuevoRol === 'User') {
        $query = "UPDATE usuarios SET Rol = ? WHERE Id = ?";
        $stmt = mysqli_prepare($db, $query);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 'si', $nuevoRol, $idUsuario);
            if (mysqli_stmt_execute($stmt)) {
                $mensaje = "Rol actualizado exitosamente";
            } else {
                $mensaje = "Error al actualizar el rol: " . mysqli_error($db);
            }
            mysqli_stmt_close($stmt);
        }
    }
}

// Procesar el aumento de cubetas
if (isset($_POST['aumentarCubetas'])) {
    $idUsuario = (int) filter_var($_POST['idUsuarioCubetas'], FILTER_SANITIZE_NUMBER_INT);
    $cubetasAgregar = (int) filter_var($_POST['cubetasAgregar'], FILTER_SANITIZE_NUMBER_INT);

    $query = "UPDATE usuarios SET CubetasTot = CubetasTot + ? WHERE Id = ?";
    $stmt = mysqli_prepare($db, $query);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'ii', $cubetasAgregar, $idUsuario);
        if (mysqli_stmt_execute($stmt)) {
            // Recuperar datos del usuario actualizado
            $queryUsuario = "SELECT Nombre, CubetasTot FROM usuarios WHERE Id = ?";
            $stmtUsuario = mysqli_prepare($db, $queryUsuario);
            if ($stmtUsuario) {
                mysqli_stmt_bind_param($stmtUsuario, 'i', $idUsuario);
                mysqli_stmt_execute($stmtUsuario);
                $resultUsuario = mysqli_stmt_get_result($stmtUsuario);
                if ($fila = mysqli_fetch_assoc($resultUsuario)) {
                    $NombreUser = $fila['Nombre'];
                    $CubTot = $fila['CubetasTot'];
                    $CubetasRes = 4 - ($CubTot % 4);
                    $CubetasRes = $CubetasRes === 4 ? 0 : $CubetasRes;

                    if ($CubetasRes === 0) {
                        $mensajeCubetas = "Se agregaron $cubetasAgregar cubetas a $NombreUser. ¡Otorgar composta!";
                    } else {
                        $mensajeCubetas = "Se agregaron $cubetasAgregar cubetas a $NombreUser. Cubetas restantes para el premio: $CubetasRes.";
                    }
                }
                mysqli_stmt_close($stmtUsuario);
            }
        } else {
            $mensajeCubetas = "Error al actualizar las cubetas: " . mysqli_error($db);
        }
        mysqli_stmt_close($stmt);
    }
}

// Sentencia para ver el perfil del usuario
$VerPerfilUsuario = $_POST['idUsuarioParaVer'] ?? NULL;
$ExisteUsuarioBusqueda = false;

if ($VerPerfilUsuario) {
    $IDConsultada = $VerPerfilUsuario;
    $query = "SELECT * FROM usuarios WHERE Id = ?";
    $stmt = mysqli_prepare($db, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'i', $IDConsultada);
        mysqli_stmt_execute($stmt);
        $resultado = mysqli_stmt_get_result($stmt);

        if ($fila = mysqli_fetch_assoc($resultado)) {
            $ExisteUsuarioBusqueda = true;
            $NombreUser = $fila['Nombre'];
            $ApPat = $fila['ApPat'];
            $ApMat = $fila['ApMat'];
            $CubTot = $fila['CubetasTot'];
            $FechaNac = $fila['FNacimiento'];
            $FRegistro = $fila['FRegistro'];
            $Rol = $fila['Rol'];

            date_default_timezone_set('America/Mexico_City');
            $fecha_actual = new DateTime();
            $fecha_nacimiento = new DateTime($FechaNac);
            $edad = $fecha_actual->diff($fecha_nacimiento)->y;

            $fecha_registro = new DateTime($FRegistro);
            $diferencia_dias = $fecha_actual->diff($fecha_registro)->days;
            $CubetasRes = 4 - ($CubTot % 4);
            $CubetasRes = $CubetasRes === 4 ? 0 : $CubetasRes;

            if ($edad > 120) $edad = 'Fecha mal proporcionada';
        }
    }
}

?>

<section class="administrador">
    <h1>Administrar Usuarios</h1>

    <?php if (!empty($mensaje)): ?>
        <p class="mensaje"><?php echo htmlspecialchars($mensaje); ?></p>
    <?php endif; ?>

    <?php if (!empty($mensajeCubetas)): ?>
        <p class="mensaje"><?php echo htmlspecialchars($mensajeCubetas); ?></p>
    <?php endif; ?>

    <div class="cubetas">
    <h2>Cambiar Rol de Usuario</h2>
    <form method="POST" action="">
        <div class="pregunta1">
        <label for="idUsuarioRol">ID del Usuario:</label>
        <input type="number" name="idUsuario" id="idUsuarioRol" required>
        </div>
        <div class="pregunta2">
        <label for="nuevoRol">Nuevo Rol:</label>
        <select name="nuevoRol" id="nuevoRol" required>
            <option value="Admin">Admin</option>
            <option value="User">Usuario</option>
        </select>
        </div>
        <button type="submit" name="cambiarRol">Cambiar Rol</button>
    </form>
    </div>

    <div class="cubetas">
        <h2>Modificar Cubetas</h2>
        
        <form method="POST" action="">
            <div class="pregunta1">
            <label for="idUsuarioCubetas">ID del Usuario:</label>
            <input type="number" name="idUsuarioCubetas" id="idUsuarioCubetas" required>
            </div>
            <div class="pregunta2">
            <label for="cubetasAgregar">Cantidad de Cubetas:</label>
            <input type="number" name="cubetasAgregar" id="cubetasAgregar" required>
            </div>
            <button type="submit" name="aumentarCubetas">Modificar Cubetas</button>
        </form>
    </div>

    <h2>Ver Perfil de Usuario</h2>
    <form method="POST" id="FormularioVerPerfilPorID">
        <label for="idUsuarioPerfil">ID del Usuario:</label>
        <input type="number" name="idUsuarioParaVer" id="idUsuarioPerfil" required>
        <button type="submit">Ver Perfil</button>
    </form>
</section>

<?php if ($VerPerfilUsuario && $ExisteUsuarioBusqueda): ?>
    <div class='perfil-usuario' id='VerUnPerfil'>
        <h3>Perfil de búsqueda del usuario con ID <?php echo $VerPerfilUsuario ?></h3>
        <?php ImprimirUser($NombreUser, $edad, $CubTot, $IDConsultada, $ApPat, $ApMat, $diferencia_dias, $CubetasRes, $Rol); ?>
    </div>
<?php elseif ($VerPerfilUsuario): ?>
    <h3>El usuario buscado no existe</h3>
<?php endif; ?>
