<?php
    session_start();
    require_once '../includes/funciones.php';
    require_once '../includes/config/database.php';
    $db = conectarDB();
    
    incluirTemplate('header');
    
    require_once '../Usuario/Visualizardatos/Datosprincipales.php';
    require_once 'Visualizardatos/DatosprincipalesAdmin.php';

    incluirTemplate('footer');   
    
    mysqli_close($db);
    ?>
    

